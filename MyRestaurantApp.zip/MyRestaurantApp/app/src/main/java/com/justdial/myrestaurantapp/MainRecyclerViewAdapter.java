package com.justdial.myrestaurantapp;

import android.app.Activity;
import android.content.Context;

import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by 4vjf on 02-Jul-16.
 */
public class MainRecyclerViewAdapter extends RecyclerView.Adapter {
    private RequestQueue requestQueue;
    private VolleySingleton volleySingleton;
    Handler handler;
    LayoutInflater inflater;
    Context mCtx;
    JSONObject obj;
    ImageLoader imageLoader;
    int[] task_image = {R.drawable.home_delivery,R.drawable.book_table};
    int[] category_image = {R.drawable.trending,R.drawable.cuisines,R.drawable.foodie_delights,R.drawable.nightlife,
            R.drawable.pizza,R.drawable.coffee,R.drawable.bakeries,R.drawable.desserts};
    int view_all_image = R.drawable.view_all;
    int[] suggestion_image = {R.drawable.south_indian_restaurant,R.drawable.punjabi_restaurant,R.drawable.italian};



    MainRecyclerViewAdapter(Context context, JSONObject obj,Handler handler){
        mCtx = context;
        this.obj = obj;
        inflater = LayoutInflater.from(context);
        volleySingleton = VolleySingleton.getInstance();
        requestQueue = volleySingleton.getRequestQueue();
        imageLoader = volleySingleton.getImageLoader();
        this.handler = handler;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        // banner view
        if(viewType == 0) {
            CardView view = (CardView) inflater.inflate(R.layout.banner_layout, parent, false);
            SnappyRecyclerView bannerRecyclerView = (SnappyRecyclerView) view.findViewById(R.id.bannerRecyclerView);
            bannerRecyclerView.setLayoutManager(new LinearLayoutManager(mCtx, LinearLayoutManager.HORIZONTAL, false));
            bannerRecyclerView.setAdapter(new BannerAdapter(mCtx,obj.optJSONArray(Keys.BANNER)));
            bannerRecyclerView.setHandler(handler);
            return new RecyclerView.ViewHolder(view) {
                @Override
                public String toString() {
                    return super.toString();
                }
            };
        }

        if (viewType == 1){
            JSONArray task = obj.optJSONArray(Keys.TASK);
            LinearLayout view= (LinearLayout) inflater.inflate(R.layout.task_layout,parent,false);
          for(int i=0;i<task.length();i++) {
                View newView = inflater.inflate(R.layout.task_element,view,false);
                ImageView imageView = (ImageView)newView.findViewById(R.id.taskElementImage);
                TextView textView = (TextView)newView.findViewById(R.id.taskElementText);
                String temp = task.optJSONObject(i).optString(Keys.CATDNAME);
                textView.setText(temp);
                newView.setOnClickListener(new MainClickLister(temp));
                imageView.setImageResource(task_image[i]);
                view.addView(newView);
          }

            return new RecyclerView.ViewHolder(view) {
                @Override
                public String toString() {
                    return super.toString();
                }
            };
        }

        if (viewType == 2){
            JSONArray categorySection = obj.optJSONArray(Keys.CATEGORY);
            LinearLayout view = (LinearLayout) inflater.inflate(R.layout.category_section_layout,parent,false);
            for(int i=0;i<categorySection.length();i++){
                LinearLayout linearLayout = new LinearLayout(mCtx);
                linearLayout.setWeightSum(2);
                int j;
                for(j=i;j<(i+2);j++){
                    String temp = categorySection.optJSONObject(j).optString(Keys.CATDNAME);
                    View categoryElement = inflater.inflate(R.layout.category_section_element,linearLayout,false);
                    TextView textView = (TextView) categoryElement.findViewById(R.id.categorySectionElementText);
                    ImageView imageView = (ImageView) categoryElement.findViewById(R.id.categorySectionItemImage);
                    imageView.setImageResource(category_image[j]);
                    textView.setText(temp);
                    categoryElement.setOnClickListener(new MainClickLister(temp));
                    linearLayout.addView(categoryElement);

                }
                i=j;
                view.addView(linearLayout);
            }
            View viewAll = inflater.inflate(R.layout.category_section_element,view,false);
            ImageView imageView = (ImageView) viewAll.findViewById(R.id.categorySectionItemImage);
            imageView.setImageResource(view_all_image);
            TextView viewAllText = (TextView) viewAll.findViewById(R.id.categorySectionElementText);
            viewAll.setOnClickListener(new MainClickLister("View All"));
            viewAllText.setText("View All");
            view.addView(viewAll);
            return new RecyclerView.ViewHolder(view) {
                @Override
                public String toString() {
                    return super.toString();
                }
            };
        }

            View view = inflater.inflate(R.layout.suggestion_element,parent,false);
            return new SuggestionViewHolder(view);


    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if(holder instanceof SuggestionViewHolder){
            JSONArray suggestion = obj.optJSONArray(Keys.SUGGESTION);
            String temp = suggestion.optJSONObject(position-3).optString(Keys.CATDNAME);
            ((SuggestionViewHolder) holder).name.setText(temp);
            ((SuggestionViewHolder) holder).setOnClickListener(temp);
            ((SuggestionViewHolder) holder).imageView.setImageResource(suggestion_image[position-3]);
        }
    }




    @Override
    public int getItemViewType(int position) {
        if(position<3){
            return position;
        }
        return 3;
    }

    @Override
    public int getItemCount() {
        return 6;
    }

    public class SuggestionViewHolder extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView name;
        TextView textView1;
        TextView textView2;
        @Override
        public String toString() {
            return super.toString();
        }
        public SuggestionViewHolder(View itemView) {
            super(itemView);
            imageView = (ImageView) itemView.findViewById(R.id.suggestionElementImage);
            name = (TextView) itemView.findViewById(R.id.suggestionElementName);
            textView1 = (TextView) itemView.findViewById(R.id.suggestionElementDescription1);
            textView2 = (TextView) itemView.findViewById(R.id.suggestionElementDescription2);
        }
        public void setOnClickListener(String temp){
            itemView.setOnClickListener(new MainClickLister(temp));
        }

    }

    private class MainClickLister implements View.OnClickListener{
        String string;
        MainClickLister(String string){
            this.string = string;

        }
        @Override
        public void onClick(View view) {
            Toast.makeText(mCtx,string,Toast.LENGTH_SHORT).show();
        }
    }
}
