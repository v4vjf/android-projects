package com.justdial.myrestaurantapp;

import android.app.Activity;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by justdial on 7/7/16.
 */
public class ViewPage extends AppCompatActivity implements ViewPager.OnClickListener,ViewPager.OnPageChangeListener {





    @Override
    public void onClick(View view) {

    }

    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

    }

    @Override
    public void onPageSelected(int position) {

    }

    @Override
    public void onPageScrollStateChanged(int state) {

    }
}
