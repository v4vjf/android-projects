package com.justdial.myrestaurantapp;

/**
 * Created by justdial on 28/6/16.
 */
public class UtilClass {


    public static String getImagePath(String string){
        return string;
    }

}
