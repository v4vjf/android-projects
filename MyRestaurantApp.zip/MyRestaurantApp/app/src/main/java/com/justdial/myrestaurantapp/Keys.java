package com.justdial.myrestaurantapp;

/**
 * Created by justdial on 27/6/16.
 */
public abstract class Keys {
    public static final String CATDNAME ="catdname";
    public static final String IMG = "img";
    public static final String DESCRIPTION = "description";
    public static final String BOOK_TABLE = "Book Table";
    public static final String ORDER_NOW = "Home Delivery";
    public static final String IMAGE_PATH = "icon_path";
    public static final String FOODIE_DELIGHT = "Foodie Delights";
    public static final String TRENDING = "Trending";
    public static final String CUSISINES = "Cuisines";
    public static final String NIGHTLIFE = "Nightlife";
    public static final String PIZZAS = "Pizzas";
    public static final String COFFEE = "Coffee";
    public static final String BAKERIES = "Bakeries";
    public static final String DESSERTS = "Desserts";
    public static final String VIEW_ALL = "view all";
    public static final String RESULTS = "results";
    public static final String COLUMNS ="columns";
    public static final String BANNER = "banner";
    public static final String CATEGORY = "category";
    public static final String TASK = "task";
    public static final String SUGGESTION = "suggestion";
    public static final String TOTAL_NUM_OF_RESULTS = "totalnoofresult";
}
