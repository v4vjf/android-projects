package com.justdial.myrestaurantapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class SplashActivity extends AppCompatActivity implements ViewPager.OnPageChangeListener {
    ViewPager intro_images;
    LinearLayout pager_indicator;
    PagerAdapter mAdapter;
    private int dotsCount;
    private ImageView[] dots;
    private int[] mImageResources = {R.drawable.splash_1,R.drawable.splash_2,R.drawable.splash_3,};
    boolean bool = false;
    boolean callHappened = false;
    private Handler mHandler;
    private final int AUTOSCROLLDELAY = 3000;
    boolean dragging = false;
    private int currentItem;

    @Override
    protected void onResume() {
        super.onResume();
        callHappened = false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /*
            SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(getBaseContext());
        boolean previouslyStarted = prefs.getBoolean(getString(R.string.pref_previously_started), false);
        if(!previouslyStarted) {
            SharedPreferences.Editor edit = prefs.edit();
            edit.putBoolean(getString(R.string.pref_previously_started), Boolean.TRUE);
            edit.commit();
        }
        else{
            startActivity(new Intent(SplashActivity.this,MainActivity.class));
            finish();
        }
         */
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);
        intro_images = (ViewPager) findViewById(R.id.splashViewPager);
        pager_indicator = (LinearLayout) findViewById(R.id.viewPagerCountDots);
        mAdapter = new SplashViewPagerAdapter(SplashActivity.this, mImageResources);
        intro_images.setAdapter(mAdapter);
        intro_images.setCurrentItem(0);
        intro_images.addOnPageChangeListener(this);
        setUiPageViewController();
        mHandler = new Handler();
        mHandler.postDelayed(autoScroll,AUTOSCROLLDELAY);


    }

    private void setUiPageViewController() {

        dotsCount = mAdapter.getCount();
        dots = new ImageView[dotsCount];

        for (int i = 0; i < dotsCount; i++) {
            dots[i] = new ImageView(this);
            dots[i].setImageDrawable(getResources().getDrawable(R.drawable.non_selected_item_dot));

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );

            params.setMargins(4, 0, 4, 0);

            pager_indicator.addView(dots[i], params);
        }

        dots[0].setImageDrawable(getResources().getDrawable(R.drawable.selected_item_dot));
    }



    @Override
    public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
        if(bool && !callHappened && positionOffset == 0) {
            callHappened = true;
            Log.i("vyom", "position " + position + " positionOffset " + positionOffset + " oset pixels " + positionOffsetPixels);
            Intent i = new Intent(SplashActivity.this,MainActivity.class);
            startActivity(i);
           // finish();
        }

    }

    @Override
    public void onPageSelected(int position) {
        for (int i = 0; i < dotsCount; i++) {
            dots[i].setImageDrawable(getResources().getDrawable(R.drawable.non_selected_item_dot));
        }

        dots[position].setImageDrawable(getResources().getDrawable(R.drawable.selected_item_dot));

    }

    @Override
    public void onPageScrollStateChanged(int arg0) {
        // TODO Auto-generated method stub
        if(arg0 == ViewPager.SCROLL_STATE_DRAGGING){
            dragging = true;
            if(intro_images.getCurrentItem() == mAdapter.getCount() - 1)
            {
                bool = true;
                Log.i("vyom","last page");
            }
        }
        else {
            bool = false;
            dragging = false;
        }
    }

    public void onClickSkip(View view){
        Intent i = new Intent(SplashActivity.this,MainActivity.class);
        startActivity(i);
    }


    Runnable autoScroll = new Runnable() {
        @Override
        public void run() {
            currentItem = intro_images.getCurrentItem();
            if(currentItem < mAdapter.getCount() - 1){
                currentItem ++;
            }
            else {
                currentItem = 0;
                mHandler.removeCallbacksAndMessages(null);
            }
            if(!dragging) {
                intro_images.setCurrentItem(currentItem, true);
            }
            mHandler.postDelayed(this,AUTOSCROLLDELAY);
        }
    };
}
