package com.justdial.myrestaurantapp;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Created by 4vjf on 02-Jul-16.
 */
public class BannerAdapter extends RecyclerView.Adapter<BannerAdapter.BannerViewHolder>{
    private  ImageLoader imageLoader;
    private RequestQueue requestQueue;
    private VolleySingleton volleySingleton;
    private LayoutInflater inflater;
    private JSONArray banner;
    private Context mCtx;
    private int dotsCount;
    private ImageView[] dots;
    private int[] banner_image = {R.drawable.banner_1,R.drawable.banner_2,R.drawable.banner_3};
    BannerAdapter(Context context, JSONArray banner){
        mCtx = context;
        inflater = LayoutInflater.from(context);
        this.banner = banner;
        volleySingleton = VolleySingleton.getInstance();
        requestQueue = volleySingleton.getRequestQueue();
        imageLoader = volleySingleton.getImageLoader();
        dotsCount = banner.length();
    }



    @Override
    public BannerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        FrameLayout frameLayout = (FrameLayout) inflater.inflate(R.layout.banner_element,parent,false);
        BannerViewHolder bannerViewHolder = new BannerViewHolder(frameLayout);
        return bannerViewHolder;

    }

    @Override
    public void onBindViewHolder(BannerViewHolder holder, int position) {
        holder.setOnClickListener(position);
//        String description = banner.optJSONObject(position).optString(Keys.CATDNAME);
//        String imgPath = UtilClass.getImagePath(banner.optJSONObject(position).optString(Keys.IMG));
        holder.imageView.setImageResource(banner_image[position]);
//        holder.textView.setText(description);
        dots = new ImageView[dotsCount];
        for (int i = 0; i < dotsCount; i++) {
            dots[i] = new ImageView(mCtx);
            dots[i].setImageDrawable(mCtx.getResources().getDrawable(R.drawable.non_selected_item_dot));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            params.setMargins(4, 0, 4, 0);
            holder.bannerPageIndicator.addView(dots[i], params);
        }
        dots[position].setImageDrawable(mCtx.getResources().getDrawable(R.drawable.selected_item_dot));
    }


    @Override
    public int getItemCount() {
        return banner.length();
    }

    public class BannerViewHolder extends RecyclerView.ViewHolder{
        TextView textView;
        ImageView imageView;
        LinearLayout bannerPageIndicator;
        public BannerViewHolder(View itemView) {
            super(itemView);
            bannerPageIndicator = (LinearLayout) itemView.findViewById(R.id.bannerPageIndicator);
//            textView = (TextView) itemView.findViewById(R.id.bannerText);
            imageView = (ImageView) itemView.findViewById(R.id.bannerImage);
        }

        public void setOnClickListener(int position){
            itemView.setOnClickListener(new BannerClickListener(position));
        }
    }

    private class BannerClickListener implements View.OnClickListener{

        int position;
        BannerClickListener(int position){
            this.position = position;
        }

        @Override
        public void onClick(View view) {
            Toast.makeText(mCtx,(position+1)+" banner clicke",Toast.LENGTH_SHORT).show();
        }
    }
}
